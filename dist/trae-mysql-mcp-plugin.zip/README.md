# TraeMysqlMCP - 生产级 MySQL 多数据源 MCP 工具

## 项目概述

TraeMysqlMCP 是一个完全适配字节 TRAE CN IDE 环境的生产级 MySQL 多数据源管理工具。它提供了增强型连接池、安全配置、性能监控等核心功能，可直接在 TRAE CN 中部署和复用。

## 技术栈

- **基础栈**: Python 3.8+、pymysql、DBUtils>=2.0、python-dotenv、logging、threading
- **可选增强**: psutil、json5、pytest

## 核心功能

### 1. 增强型连接池
- 支持连接池动态扩容/缩容
- 记录连接使用时长和 SQL 执行耗时
- 连接池状态监控（当前连接数、空闲连接数、等待队列长度）
- 线程安全的连接管理

### 2. 安全与通用规范
- SQL 执行超时控制
- 数据源配置加密存储（AES-256）
- SQL 白名单/黑名单机制
- 危险 SQL 操作拦截

### 3. 扩展性
- 预留 PostgreSQL/Oracle 数据源接口
- 支持自定义钩子函数
- 可打包为 TRAE CN 通用代码插件

### 4. 可维护性
- 完整的单元测试覆盖
- 详细的接口文档
- 版本管理和更新日志

## 项目结构

```
TraeMysqlMCP/
├── trae_mysql_mcp/
│   ├── __init__.py          # 模块初始化
│   ├── core.py              # 核心MCP接口
│   ├── config.py            # 配置管理
│   ├── encryption.py        # 加密工具
│   ├── pool.py              # 连接池管理
│   ├── executor.py          # SQL执行器
│   ├── monitor.py           # 监控模块
│   ├── exceptions.py        # 异常定义
│   └── cli.py               # 命令行接口
├── tests/                   # 单元测试
│   ├── test_core.py
│   ├── test_config.py
│   ├── test_encryption.py
│   ├── test_monitor.py
│   └── test_pool.py
├── docs/                    # 文档
│   ├── api/                 # API文档
│   ├── configuration/       # 配置说明
│   ├── performance/         # 性能优化指南
│   └── integration/         # TRAE CN集成指南
├── requirements.txt         # 依赖配置
├── setup.py                 # 打包配置
├── README.md                # 项目说明
├── CHANGELOG.md             # 更新日志
└── .env.example             # 环境变量示例
```

## 安装与使用

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 配置环境变量

复制 `.env.example` 文件并填写数据库连接信息：

```bash
cp .env.example .env
```

### 3. 基本使用

```python
from trae_mysql_mcp import TraeMySQLMCP

# 初始化 MCP
mcp = TraeMySQLMCP()

# 连接数据源
mcp.connect('default')

# 执行 SQL
result = mcp.execute('SELECT * FROM users LIMIT 10')
print(result)

# 断开连接
mcp.disconnect()
```

### 4. 多数据源配置

```python
from trae_mysql_mcp import TraeMySQLMCP, DataSourceConfig

mcp = TraeMySQLMCP()

# 添加主库
master_config = DataSourceConfig(
    name="master",
    host="master_db",
    port=3306,
    user="root",
    password="master_password",
    database="production"
)
mcp.add_data_source(master_config)

# 添加从库
slave_config = DataSourceConfig(
    name="slave",
    host="slave_db",
    port=3306,
    user="readonly",
    password="slave_password",
    database="production"
)
mcp.add_data_source(slave_config)

# 使用不同数据源
mcp.connect('master')
mcp.execute('INSERT INTO users (name) VALUES ("test")')

mcp.connect('slave')
result = mcp.execute('SELECT * FROM users')
```

## 命令行工具

```bash
# 查看帮助
trae-mysql-mcp --help

# 连接数据源
trae-mysql-mcp connect default

# 执行 SQL
trae-mysql-mcp execute "SELECT * FROM users"

# 查看状态
trae-mysql-mcp status

# 健康检查
trae-mysql-mcp health

# 性能报告
trae-mysql-mcp performance

# 列出数据源
trae-mysql-mcp list

# 调整连接池大小
trae-mysql-mcp resize 5 20
```

## 监控与调试

### 1. 连接池状态

```python
status = mcp.get_pool_status()
print(f"当前连接数: {status['current_size']}")
print(f"活跃连接数: {status['active_size']}")
print(f"空闲连接数: {status['idle_size']}")
```

### 2. 性能报告

```python
report = mcp.get_performance_report()
print(f"总执行次数: {report['summary']['total_sql_executions']}")
print(f"成功率: {report['summary']['success_rate']:.2f}%")
print(f"平均执行时间: {report['summary']['avg_execution_time']:.3f}s")
```

### 3. 健康检查

```python
health = mcp.get_health_status()
if health['healthy']:
    print("系统健康状态良好")
else:
    print("系统存在问题:")
    for issue in health['issues']:
        print(f"- {issue}")
```

## 安全配置

### 生产环境配置

```json5
{
  "security": {
    "whitelist_enabled": true,
    "blacklist_enabled": true,
    "whitelist": ["SELECT", "INSERT", "UPDATE", "DELETE"],
    "blacklist": ["DROP", "TRUNCATE", "ALTER", "CREATE"]
  }
}
```

## 性能优化

### 1. 连接池优化

```python
# 推荐配置
config = DataSourceConfig(
    # 其他配置...
    pool_min_size=5,      # 基础并发数
    pool_max_size=15,     # 最大并发数
    pool_timeout=30,      # 连接池超时(秒)
    sql_timeout=60        # SQL执行超时(秒)
)
```

### 2. SQL 优化

- 使用参数化查询
- 批量执行操作
- 使用事务减少网络开销
- 限制结果集大小

## TRAE CN 集成

### 1. 作为插件安装

1. 打包插件：`zip -r dist/trae-mysql-mcp-plugin.zip .`
2. 在 TRAE CN 插件管理中上传并安装
3. 启用插件

### 2. 项目集成

```python
from trae_mysql_mcp import TraeMySQLMCP

# 初始化并使用
mcp = TraeMySQLMCP()
mcp.connect('default')
result = mcp.execute('SELECT * FROM users')
```

## 测试

运行单元测试：

```bash
pytest tests/ -v
```

## 版本信息

- **版本**: 1.0.0
- **发布日期**: 2026-03-11
- **Python 版本**: 3.8+

## 许可证

MIT License

## 更新日志

### v1.0.0 (2026-03-11)
- 初始版本发布
- 实现核心连接池管理
- 实现加密存储功能
- 实现 SQL 执行器和监控功能
- 完整的单元测试覆盖
- 详细的文档和使用指南

## 技术支持

如有任何问题，请参考文档或联系技术支持。
